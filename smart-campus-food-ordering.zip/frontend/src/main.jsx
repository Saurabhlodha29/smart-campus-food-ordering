import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "react-hot-toast";
import App from "./App";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: { queries: { retry: 1, staleTime: 30_000 } },
});

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <App />
      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            background: "#2A1A0A",
            color: "#FFFFFF",
            border: "1px solid rgba(255,101,0,0.25)",
            fontFamily: "Poppins, sans-serif",
          },
        }}
      />
    </QueryClientProvider>
  </React.StrictMode>
);
